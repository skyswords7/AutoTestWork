create definer = root@localhost trigger create_reply_notice
    after insert
    on reply
    for each row
begin
    declare reply_user_id int default null;
    declare post_user_id int default null;
    select user_id into reply_user_id from reply where id = new.reply_id;

    if (reply_user_id is not null and reply_user_id<>new.user_id) then
        insert ignore into reply_notice values (null, reply_user_id, new.id);
    end if;

    select user_id into post_user_id from post where id = new.post_id;

    if (post_user_id <> new.user_id) then
        insert ignore into reply_notice values (null, post_user_id, NEW.id);
    end if;
end;

